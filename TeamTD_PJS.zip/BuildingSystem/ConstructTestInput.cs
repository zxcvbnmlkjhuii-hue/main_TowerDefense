using UnityEngine;
using UnityEngine.InputSystem;

public class ConstructTestInput: MonoBehaviour
{
    [SerializeField] private ConstructController controller;
    [SerializeField] private Camera mainCamera;

    private BuildingTestInput inputActions;

    private void Awake()
    {
        inputActions = new BuildingTestInput();

        // 1. ��Ŭ�� (ModMainAction) ����
        inputActions.Building.MainAction.started += ctx =>
        {
            controller.PerformCurModeAction();
        };

        inputActions.Building.CancelAction.performed += ctx =>
        {
            controller.CancelCurModeAction();
        };

        // 2. ����Ű 1~5�� (TowerSelect) ����
        inputActions.Building.TowerSelect.performed += OnTowerSelect;
    }

    private void OnEnable()
    {
        inputActions.Enable();
    }

    private void OnDisable()
    {
        inputActions.Disable();
    }

    private void Update()
    {
        Vector2 mousePos = inputActions.Building.MousePos.ReadValue<Vector2>();
        Ray ray = mainCamera.ScreenPointToRay(mousePos);

        bool isHit = Physics.Raycast(ray, out RaycastHit hit, 1000f);

        controller.UpdateRayHitInfo(isHit, hit);
    }

    private void OnTowerSelect(InputAction.CallbackContext ctx)
    {

        if (int.TryParse(ctx.control.name, out int keyNumber))
        {
            int slotIndex = keyNumber - 1;

            controller.SelectBuildingByIndex(slotIndex);
        }
    }
}
