using UnityEngine;
using System;

public class UI_TowerQuickSlot : MonoBehaviour
{
    public event Action<int> OnSlotSelected;

    [Header("���� ����Ʈ")]
    [SerializeField] private Slot_TowerQuickSlot[] slots;

    private void OnDestroy()
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i] != null)
            {
                slots[i].OnClicked -= HandleSlotClicked;
            }
        }
    }

    public void SetupUI(GameObject[] activeTowers)
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i] == null) continue;

            //TowerDataSO data = (activeTowers != null && i < activeTowers.Length) ? activeTowers[i] : null;
            slots[i].Initialize(i);

            // ���� ���� Ŭ�� �̺�Ʈ ����
            slots[i].OnClicked += HandleSlotClicked;
        }
    }

    private void HandleSlotClicked(int index)
    {
        UpdateHighlight(index);

        OnSlotSelected?.Invoke(index);
    }

    public void UpdateHighlight(int selectedIndex)
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i] != null)
            {
                slots[i].SetHighlight(i == selectedIndex);
            }
        }
    }

    public void ClearHighlight()
    {
        foreach (var slot in slots)
        {
            if (slot != null) slot.SetHighlight(false);
        }
    }


}
