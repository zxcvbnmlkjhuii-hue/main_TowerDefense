using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;

public class Slot_TowerQuickSlot : MonoBehaviour
{
    public event Action<int> OnClicked;

    [Header("���� ���� UI ���")]
    [SerializeField] private Button slotButton;
    [SerializeField] private TextMeshProUGUI costText;
    [SerializeField] private Image slotIcon;
    [SerializeField] private GameObject highlightFrame;

    private int slotIndex;

    public void Initialize(int index)
    {
        this.slotIndex = index;

        if (slotButton != null)
        {
            slotButton.onClick.RemoveAllListeners();
            slotButton.onClick.AddListener(HandleClick);
        }

        SetSlotData(null);
    }

    public void SetSlotData(GameObject data)
    {
        if (data != null && slotIcon != null)
        {
            //slotIcon.sprite = data.towerIcon;
            slotIcon.enabled = true;
        }
        else if (slotIcon != null)
        {
            slotIcon.enabled = false;
        }
    }

    public void SetHighlight(bool isActive)
    {
        if (highlightFrame != null)
        {
            highlightFrame.SetActive(isActive);
        }
    }

    private void HandleClick()
    {
        OnClicked?.Invoke(slotIndex);
    }
}
