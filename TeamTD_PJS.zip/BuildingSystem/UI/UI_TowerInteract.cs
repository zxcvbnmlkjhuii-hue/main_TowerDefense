using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.EventSystems;

public class UI_TowerInteract : MonoBehaviour
{
    public event Action OnDestroyClicked;
    public event Action OnBarrierClickedEvent;

    [Header("UI �������")]
    [SerializeField] private RectTransform menuRect;
    [SerializeField] private Button destroyButton;  // ��ü ��ư
    [SerializeField] private ImageBarrier imageBarrier;

    [Header("����")]
    [SerializeField] private Vector3 offset = new Vector3(0, 2f, 0);

    private Camera mainCam;
    private Vector3 targetWorldPos;
    private bool isShowing = false;

    private void Awake()
    {
        mainCam = Camera.main;

        destroyButton.onClick.AddListener(() => { OnDestroyClicked?.Invoke(); });

        if(imageBarrier != null)
        {
            imageBarrier.OnClicekd += OnBarrierClicked;
        }

        Hide();
    }

    private void Update()
    {
        // Ÿ���� 3D ���� ��ǥ�� 2D ȭ��(Screen) ��ǥ�� ��ȯ�ؼ� ����ٴ�
        if (isShowing)
        {
            Vector3 screenPos = mainCam.WorldToScreenPoint(targetWorldPos + offset);
            menuRect.position = screenPos;
        }
    }

    public void Show(Vector3 worldPos)
    {
        targetWorldPos = worldPos;
        isShowing = true;
        gameObject.SetActive(true);
        imageBarrier.gameObject.SetActive(true);
        imageBarrier.OnClicekd += OnBarrierClicked;
    }

    public void Hide()
    {
        isShowing = false;
        imageBarrier.gameObject.SetActive(false);
        gameObject.SetActive(false);
        imageBarrier.OnClicekd -= OnBarrierClicked;
    }

    private void OnBarrierClicked()
    {
        OnBarrierClickedEvent?.Invoke();
    }
}
