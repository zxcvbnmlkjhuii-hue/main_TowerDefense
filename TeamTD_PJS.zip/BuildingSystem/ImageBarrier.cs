using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class ImageBarrier : MonoBehaviour, IPointerClickHandler
{
    public event Action OnClicekd;

    void IPointerClickHandler.OnPointerClick(PointerEventData eventData)
    {
        Debug.Log("Clicked");
        OnClicekd?.Invoke();
    }


}
